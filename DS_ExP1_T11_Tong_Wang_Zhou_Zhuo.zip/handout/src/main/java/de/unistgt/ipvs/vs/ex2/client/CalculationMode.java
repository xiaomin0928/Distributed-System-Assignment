package de.unistgt.ipvs.vs.ex2.client;

public enum CalculationMode {
	ADD, SUB, MUL
}
