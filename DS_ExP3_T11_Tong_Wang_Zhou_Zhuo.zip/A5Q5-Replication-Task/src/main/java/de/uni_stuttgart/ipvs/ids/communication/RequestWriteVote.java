package de.uni_stuttgart.ipvs.ids.communication;

import java.io.Serializable;

public class RequestWriteVote implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 9048777968743446224L;

}
