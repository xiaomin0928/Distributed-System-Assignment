package de.uni_stuttgart.ipvs.ids.communication;

import java.io.Serializable;

public class ReleaseReadLock implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2889680559006519738L;

}
