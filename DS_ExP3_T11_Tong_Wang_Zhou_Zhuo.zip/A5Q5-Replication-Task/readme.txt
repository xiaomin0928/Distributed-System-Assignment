run manual

*execution environment: win 10

1.Start gradle
$gradle

2.Build the project
$gradle build